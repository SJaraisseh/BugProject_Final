﻿
namespace BugTrackerv2
{
    partial class frmBugTracker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label bugNameLabel;
            System.Windows.Forms.Label bugTypeLabel;
            System.Windows.Forms.Label bugColorLabel;
            System.Windows.Forms.Label bugLengthLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBugTracker));
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.bugDatabaseDataSet = new BugTrackerv2.BugDatabaseDataSet();
            this.tblBugDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblBugDataTableAdapter = new BugTrackerv2.BugDatabaseDataSetTableAdapters.tblBugDataTableAdapter();
            this.tableAdapterManager = new BugTrackerv2.BugDatabaseDataSetTableAdapters.TableAdapterManager();
            this.bugNameTextBox = new System.Windows.Forms.TextBox();
            this.bugTypeTextBox = new System.Windows.Forms.TextBox();
            this.bugColorTextBox = new System.Windows.Forms.TextBox();
            this.bugLengthTextBox = new System.Windows.Forms.TextBox();
            this.cboBugSelection = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.bugPicPictureBox = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.bugIdTextBox = new System.Windows.Forms.TextBox();
            bugNameLabel = new System.Windows.Forms.Label();
            bugTypeLabel = new System.Windows.Forms.Label();
            bugColorLabel = new System.Windows.Forms.Label();
            bugLengthLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bugDatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblBugDataBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bugPicPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // bugNameLabel
            // 
            bugNameLabel.AutoSize = true;
            bugNameLabel.Font = new System.Drawing.Font("Pristina", 28.25F, System.Drawing.FontStyle.Bold);
            bugNameLabel.ForeColor = System.Drawing.Color.Teal;
            bugNameLabel.Location = new System.Drawing.Point(6, 18);
            bugNameLabel.Name = "bugNameLabel";
            bugNameLabel.Size = new System.Drawing.Size(114, 50);
            bugNameLabel.TabIndex = 13;
            bugNameLabel.Text = "Name:";
            // 
            // bugTypeLabel
            // 
            bugTypeLabel.AutoSize = true;
            bugTypeLabel.Font = new System.Drawing.Font("Pristina", 28.25F, System.Drawing.FontStyle.Bold);
            bugTypeLabel.ForeColor = System.Drawing.Color.DodgerBlue;
            bugTypeLabel.Location = new System.Drawing.Point(6, 71);
            bugTypeLabel.Name = "bugTypeLabel";
            bugTypeLabel.Size = new System.Drawing.Size(100, 50);
            bugTypeLabel.TabIndex = 15;
            bugTypeLabel.Text = "Type:";
            // 
            // bugColorLabel
            // 
            bugColorLabel.AutoSize = true;
            bugColorLabel.Font = new System.Drawing.Font("Pristina", 28.25F, System.Drawing.FontStyle.Bold);
            bugColorLabel.ForeColor = System.Drawing.Color.Thistle;
            bugColorLabel.Location = new System.Drawing.Point(6, 122);
            bugColorLabel.Name = "bugColorLabel";
            bugColorLabel.Size = new System.Drawing.Size(100, 50);
            bugColorLabel.TabIndex = 17;
            bugColorLabel.Text = "Color:";
            // 
            // bugLengthLabel
            // 
            bugLengthLabel.AutoSize = true;
            bugLengthLabel.Font = new System.Drawing.Font("Pristina", 28.25F, System.Drawing.FontStyle.Bold);
            bugLengthLabel.ForeColor = System.Drawing.Color.MediumVioletRed;
            bugLengthLabel.Location = new System.Drawing.Point(6, 175);
            bugLengthLabel.Name = "bugLengthLabel";
            bugLengthLabel.Size = new System.Drawing.Size(125, 50);
            bugLengthLabel.TabIndex = 19;
            bugLengthLabel.Text = "Length:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Pristina", 58.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.LightCoral;
            this.label3.Location = new System.Drawing.Point(198, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(442, 103);
            this.label3.TabIndex = 5;
            this.label3.Text = "A Bugs World";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(112, 95);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClose.Font = new System.Drawing.Font("OCR A Extended", 15F);
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(12, 382);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(183, 36);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // bugDatabaseDataSet
            // 
            this.bugDatabaseDataSet.DataSetName = "BugDatabaseDataSet";
            this.bugDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblBugDataBindingSource
            // 
            this.tblBugDataBindingSource.DataMember = "tblBugData";
            this.tblBugDataBindingSource.DataSource = this.bugDatabaseDataSet;
            // 
            // tblBugDataTableAdapter
            // 
            this.tblBugDataTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tblBugDataTableAdapter = this.tblBugDataTableAdapter;
            this.tableAdapterManager.UpdateOrder = BugTrackerv2.BugDatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // bugNameTextBox
            // 
            this.bugNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblBugDataBindingSource, "bugName", true));
            this.bugNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bugNameTextBox.Location = new System.Drawing.Point(163, 19);
            this.bugNameTextBox.MaxLength = 50;
            this.bugNameTextBox.Name = "bugNameTextBox";
            this.bugNameTextBox.ReadOnly = true;
            this.bugNameTextBox.Size = new System.Drawing.Size(293, 44);
            this.bugNameTextBox.TabIndex = 0;
            this.bugNameTextBox.TabStop = false;
            // 
            // bugTypeTextBox
            // 
            this.bugTypeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblBugDataBindingSource, "bugType", true));
            this.bugTypeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bugTypeTextBox.Location = new System.Drawing.Point(163, 71);
            this.bugTypeTextBox.MaxLength = 50;
            this.bugTypeTextBox.Name = "bugTypeTextBox";
            this.bugTypeTextBox.ReadOnly = true;
            this.bugTypeTextBox.Size = new System.Drawing.Size(293, 44);
            this.bugTypeTextBox.TabIndex = 1;
            this.bugTypeTextBox.TabStop = false;
            // 
            // bugColorTextBox
            // 
            this.bugColorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblBugDataBindingSource, "bugColor", true));
            this.bugColorTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bugColorTextBox.Location = new System.Drawing.Point(163, 123);
            this.bugColorTextBox.MaxLength = 50;
            this.bugColorTextBox.Name = "bugColorTextBox";
            this.bugColorTextBox.ReadOnly = true;
            this.bugColorTextBox.Size = new System.Drawing.Size(293, 44);
            this.bugColorTextBox.TabIndex = 2;
            this.bugColorTextBox.TabStop = false;
            // 
            // bugLengthTextBox
            // 
            this.bugLengthTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblBugDataBindingSource, "bugLength", true));
            this.bugLengthTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bugLengthTextBox.Location = new System.Drawing.Point(163, 176);
            this.bugLengthTextBox.MaxLength = 50;
            this.bugLengthTextBox.Name = "bugLengthTextBox";
            this.bugLengthTextBox.ReadOnly = true;
            this.bugLengthTextBox.Size = new System.Drawing.Size(293, 44);
            this.bugLengthTextBox.TabIndex = 3;
            this.bugLengthTextBox.TabStop = false;
            // 
            // cboBugSelection
            // 
            this.cboBugSelection.BackColor = System.Drawing.Color.DimGray;
            this.cboBugSelection.DataSource = this.tblBugDataBindingSource;
            this.cboBugSelection.DisplayMember = "bugName";
            this.cboBugSelection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBugSelection.Font = new System.Drawing.Font("Pristina", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboBugSelection.ForeColor = System.Drawing.Color.Salmon;
            this.cboBugSelection.FormattingEnabled = true;
            this.cboBugSelection.Location = new System.Drawing.Point(201, 385);
            this.cboBugSelection.Name = "cboBugSelection";
            this.cboBugSelection.Size = new System.Drawing.Size(471, 54);
            this.cboBugSelection.TabIndex = 0;
            this.cboBugSelection.ValueMember = "bugName";
            this.cboBugSelection.SelectedIndexChanged += new System.EventHandler(this.cboBugSelection_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.MidnightBlue;
            this.groupBox1.Controls.Add(this.bugNameTextBox);
            this.groupBox1.Controls.Add(this.bugLengthTextBox);
            this.groupBox1.Controls.Add(bugNameLabel);
            this.groupBox1.Controls.Add(bugLengthLabel);
            this.groupBox1.Controls.Add(bugTypeLabel);
            this.groupBox1.Controls.Add(bugColorLabel);
            this.groupBox1.Controls.Add(this.bugColorTextBox);
            this.groupBox1.Controls.Add(this.bugTypeTextBox);
            this.groupBox1.Location = new System.Drawing.Point(201, 143);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(471, 236);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnAdd
            // 
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd.Font = new System.Drawing.Font("OCR A Extended", 15F);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.Location = new System.Drawing.Point(489, 445);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(183, 36);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Add More";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Font = new System.Drawing.Font("OCR A Extended", 15F);
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.Location = new System.Drawing.Point(489, 487);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(183, 36);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // bugPicPictureBox
            // 
            this.bugPicPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.bugPicPictureBox.DataBindings.Add(new System.Windows.Forms.Binding("Image", this.tblBugDataBindingSource, "bugPic", true));
            this.bugPicPictureBox.Location = new System.Drawing.Point(12, 143);
            this.bugPicPictureBox.Name = "bugPicPictureBox";
            this.bugPicPictureBox.Size = new System.Drawing.Size(183, 233);
            this.bugPicPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bugPicPictureBox.TabIndex = 25;
            this.bugPicPictureBox.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(130, 75);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(87, 62);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 27;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(413, 86);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(87, 62);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 31;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(584, 86);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(87, 62);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 29;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(37, 424);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(424, 445);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(59, 54);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 28;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(216, 458);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(74, 65);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 30;
            this.pictureBox6.TabStop = false;
            // 
            // bugIdTextBox
            // 
            this.bugIdTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblBugDataBindingSource, "bugId", true));
            this.bugIdTextBox.Enabled = false;
            this.bugIdTextBox.Location = new System.Drawing.Point(12, 511);
            this.bugIdTextBox.Name = "bugIdTextBox";
            this.bugIdTextBox.ReadOnly = true;
            this.bugIdTextBox.Size = new System.Drawing.Size(100, 20);
            this.bugIdTextBox.TabIndex = 32;
            this.bugIdTextBox.TextChanged += new System.EventHandler(this.bugIdTextBox_TextChanged);
            // 
            // frmBugTracker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(692, 543);
            this.Controls.Add(this.bugIdTextBox);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bugPicPictureBox);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cboBugSelection);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label3);
            this.Name = "frmBugTracker";
            this.Text = "Bug Tracker";
            this.Load += new System.EventHandler(this.frmBugTracker_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bugDatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblBugDataBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bugPicPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnClose;
        private BugDatabaseDataSet bugDatabaseDataSet;
        private System.Windows.Forms.BindingSource tblBugDataBindingSource;
        private BugDatabaseDataSetTableAdapters.tblBugDataTableAdapter tblBugDataTableAdapter;
        private BugDatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox bugNameTextBox;
        private System.Windows.Forms.TextBox bugTypeTextBox;
        private System.Windows.Forms.TextBox bugColorTextBox;
        private System.Windows.Forms.TextBox bugLengthTextBox;
        private System.Windows.Forms.ComboBox cboBugSelection;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.PictureBox bugPicPictureBox;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox bugIdTextBox;
    }
}

