﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BugTrackerv2
{
    public partial class frmAdd : Form
    {
        string fileName;
        List<tblBugData> bugPicList;
        byte[] imgbyte;

        public string strName = "";
        public string strType = "";
        public string strColor = "";
        public string strLength = "";
        public frmAdd()
        {
            InitializeComponent();
        }

        private void tblBugDataBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tblBugDataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bugDatabaseDataSet);

        }

        private void frmAdd_Load(object sender, EventArgs e)
        {

        }
        private async void btnSave_Click(object sender, EventArgs e)
        {
            // empty boxes handling
            if (bugNameTextBox.Text == "")
            {
                MessageBox.Show("Enter a Name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bugNameTextBox.Focus();
            }
            else if (bugTypeTextBox.Text == "")
            {
                MessageBox.Show("Enter a bug type.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bugTypeTextBox.Focus();
            }
            else if (bugColorTextBox.Text == "")
            {
                MessageBox.Show("Enter a color.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bugColorTextBox.Focus();
            }
            else if (bugLengthTextBox.Text == "")
            {
                MessageBox.Show("Enter a length for your bug.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bugLengthTextBox.Focus();
            }
            else if (bugPicPictureBox.Image == null)
            {
                MessageBox.Show("An image must be selected before saving.","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnBrowse.Focus();
            }
            else
            {
                using (BugDatabaseEntities1 db = new BugDatabaseEntities1())
                {

                    tblBugData pic = new tblBugData() { bugPic = ConvertImageToBinary(bugPicPictureBox.Image) };
                    imgbyte = pic.bugPic;
                    // vars
                    strName = bugNameTextBox.Text;
                    strType = bugTypeTextBox.Text;
                    strColor = bugColorTextBox.Text;
                    strLength = bugLengthTextBox.Text;
                    // TODO: This line of code loads data into the 'bugDatabaseDataSet.tblBugData' table. You can move, or remove it, as needed.
                    this.tblBugDataTableAdapter.InsertQuery(strName, strType, strColor, strLength,imgbyte);
                    // makes sure all operations are complete before saving asynchronously 
                    await db.SaveChangesAsync();
                    // display message confirming everything is saved
                    MessageBox.Show("Successfully Saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                // update database
                this.Validate();
                this.tblBugDataBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.bugDatabaseDataSet);
                // close form
                Close();
            }
        }
        // method to convert image to binary
        byte[] ConvertImageToBinary (Image img)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                return ms.ToArray();
            }
        }
        private void bugPicPictureBox_Click(object sender, EventArgs e)
        {
            
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            // Open dialog to select image
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "JPEG|*.jpg", ValidateNames = true, Multiselect = false })
            {
                // if everything passes
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    // display image in picture box
                    fileName = ofd.FileName;
                    bugPicPictureBox.Image = Image.FromFile(fileName);
                }
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Close form
            Close();
        }
    }
}
