﻿
namespace BugTrackerv2
{
    partial class frmAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label bugNameLabel1;
            System.Windows.Forms.Label bugTypeLabel1;
            System.Windows.Forms.Label bugColorLabel1;
            System.Windows.Forms.Label bugLengthLabel1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdd));
            this.bugPicPictureBox = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bugNameTextBox = new System.Windows.Forms.TextBox();
            this.bugTypeTextBox = new System.Windows.Forms.TextBox();
            this.bugColorTextBox = new System.Windows.Forms.TextBox();
            this.bugLengthTextBox = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.bugDatabaseDataSet = new BugTrackerv2.BugDatabaseDataSet();
            this.tblBugDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblBugDataTableAdapter = new BugTrackerv2.BugDatabaseDataSetTableAdapters.tblBugDataTableAdapter();
            this.tableAdapterManager = new BugTrackerv2.BugDatabaseDataSetTableAdapters.TableAdapterManager();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            bugNameLabel1 = new System.Windows.Forms.Label();
            bugTypeLabel1 = new System.Windows.Forms.Label();
            bugColorLabel1 = new System.Windows.Forms.Label();
            bugLengthLabel1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bugPicPictureBox)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bugDatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblBugDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // bugNameLabel1
            // 
            bugNameLabel1.AutoSize = true;
            bugNameLabel1.Font = new System.Drawing.Font("Pristina", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            bugNameLabel1.ForeColor = System.Drawing.Color.SaddleBrown;
            bugNameLabel1.Location = new System.Drawing.Point(18, 27);
            bugNameLabel1.Name = "bugNameLabel1";
            bugNameLabel1.Size = new System.Drawing.Size(117, 52);
            bugNameLabel1.TabIndex = 2;
            bugNameLabel1.Text = "Name:";
            // 
            // bugTypeLabel1
            // 
            bugTypeLabel1.AutoSize = true;
            bugTypeLabel1.Font = new System.Drawing.Font("Pristina", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            bugTypeLabel1.ForeColor = System.Drawing.Color.DodgerBlue;
            bugTypeLabel1.Location = new System.Drawing.Point(18, 78);
            bugTypeLabel1.Name = "bugTypeLabel1";
            bugTypeLabel1.Size = new System.Drawing.Size(104, 52);
            bugTypeLabel1.TabIndex = 4;
            bugTypeLabel1.Text = "Type:";
            // 
            // bugColorLabel1
            // 
            bugColorLabel1.AutoSize = true;
            bugColorLabel1.Font = new System.Drawing.Font("Pristina", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            bugColorLabel1.ForeColor = System.Drawing.Color.DarkViolet;
            bugColorLabel1.Location = new System.Drawing.Point(18, 130);
            bugColorLabel1.Name = "bugColorLabel1";
            bugColorLabel1.Size = new System.Drawing.Size(103, 52);
            bugColorLabel1.TabIndex = 6;
            bugColorLabel1.Text = "Color:";
            // 
            // bugLengthLabel1
            // 
            bugLengthLabel1.AutoSize = true;
            bugLengthLabel1.Font = new System.Drawing.Font("Pristina", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            bugLengthLabel1.ForeColor = System.Drawing.Color.DarkSlateGray;
            bugLengthLabel1.Location = new System.Drawing.Point(18, 182);
            bugLengthLabel1.Name = "bugLengthLabel1";
            bugLengthLabel1.Size = new System.Drawing.Size(126, 52);
            bugLengthLabel1.TabIndex = 8;
            bugLengthLabel1.Text = "Length:";
            // 
            // bugPicPictureBox
            // 
            this.bugPicPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.bugPicPictureBox.Location = new System.Drawing.Point(7, 102);
            this.bugPicPictureBox.Name = "bugPicPictureBox";
            this.bugPicPictureBox.Size = new System.Drawing.Size(185, 245);
            this.bugPicPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bugPicPictureBox.TabIndex = 23;
            this.bugPicPictureBox.TabStop = false;
            this.bugPicPictureBox.Click += new System.EventHandler(this.bugPicPictureBox_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Pristina", 50.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label3.Location = new System.Drawing.Point(194, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(291, 90);
            this.label3.TabIndex = 22;
            this.label3.Text = "Add a Bug";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Ivory;
            this.groupBox1.Controls.Add(bugNameLabel1);
            this.groupBox1.Controls.Add(this.bugNameTextBox);
            this.groupBox1.Controls.Add(bugTypeLabel1);
            this.groupBox1.Controls.Add(this.bugTypeTextBox);
            this.groupBox1.Controls.Add(bugColorLabel1);
            this.groupBox1.Controls.Add(this.bugColorTextBox);
            this.groupBox1.Controls.Add(bugLengthLabel1);
            this.groupBox1.Controls.Add(this.bugLengthTextBox);
            this.groupBox1.Location = new System.Drawing.Point(198, 102);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(478, 245);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            // 
            // bugNameTextBox
            // 
            this.bugNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.25F);
            this.bugNameTextBox.Location = new System.Drawing.Point(167, 27);
            this.bugNameTextBox.MaxLength = 50;
            this.bugNameTextBox.Name = "bugNameTextBox";
            this.bugNameTextBox.Size = new System.Drawing.Size(295, 44);
            this.bugNameTextBox.TabIndex = 3;
            // 
            // bugTypeTextBox
            // 
            this.bugTypeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.25F);
            this.bugTypeTextBox.Location = new System.Drawing.Point(167, 79);
            this.bugTypeTextBox.MaxLength = 50;
            this.bugTypeTextBox.Name = "bugTypeTextBox";
            this.bugTypeTextBox.Size = new System.Drawing.Size(295, 44);
            this.bugTypeTextBox.TabIndex = 5;
            // 
            // bugColorTextBox
            // 
            this.bugColorTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.25F);
            this.bugColorTextBox.Location = new System.Drawing.Point(167, 131);
            this.bugColorTextBox.MaxLength = 50;
            this.bugColorTextBox.Name = "bugColorTextBox";
            this.bugColorTextBox.Size = new System.Drawing.Size(295, 44);
            this.bugColorTextBox.TabIndex = 7;
            // 
            // bugLengthTextBox
            // 
            this.bugLengthTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.25F);
            this.bugLengthTextBox.Location = new System.Drawing.Point(167, 183);
            this.bugLengthTextBox.MaxLength = 50;
            this.bugLengthTextBox.Name = "bugLengthTextBox";
            this.bugLengthTextBox.Size = new System.Drawing.Size(295, 44);
            this.bugLengthTextBox.TabIndex = 9;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Font = new System.Drawing.Font("OCR A Extended", 15F);
            this.btnBrowse.Image = ((System.Drawing.Image)(resources.GetObject("btnBrowse.Image")));
            this.btnBrowse.Location = new System.Drawing.Point(7, 353);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(185, 36);
            this.btnBrowse.TabIndex = 20;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(491, 353);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(185, 36);
            this.btnSave.TabIndex = 19;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("OCR A Extended", 15F);
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.Location = new System.Drawing.Point(491, 395);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(185, 36);
            this.btnCancel.TabIndex = 18;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // bugDatabaseDataSet
            // 
            this.bugDatabaseDataSet.DataSetName = "BugDatabaseDataSet";
            this.bugDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblBugDataBindingSource
            // 
            this.tblBugDataBindingSource.DataMember = "tblBugData";
            this.tblBugDataBindingSource.DataSource = this.bugDatabaseDataSet;
            // 
            // tblBugDataTableAdapter
            // 
            this.tblBugDataTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tblBugDataTableAdapter = this.tblBugDataTableAdapter;
            this.tableAdapterManager.UpdateOrder = BugTrackerv2.BugDatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(56, 395);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 37;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(491, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(87, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 38;
            this.pictureBox2.TabStop = false;
            // 
            // frmAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(688, 465);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bugPicPictureBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Name = "frmAdd";
            this.Text = "Add";
            this.Load += new System.EventHandler(this.frmAdd_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bugPicPictureBox)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bugDatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblBugDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox bugPicPictureBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox bugNameTextBox;
        private System.Windows.Forms.TextBox bugTypeTextBox;
        private System.Windows.Forms.TextBox bugColorTextBox;
        private System.Windows.Forms.TextBox bugLengthTextBox;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private BugDatabaseDataSet bugDatabaseDataSet;
        private System.Windows.Forms.BindingSource tblBugDataBindingSource;
        private BugDatabaseDataSetTableAdapters.tblBugDataTableAdapter tblBugDataTableAdapter;
        private BugDatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}