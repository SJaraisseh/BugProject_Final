﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BugTrackerv2
{
    public partial class frmBugTracker : Form
    {
        public frmBugTracker()
        {
            InitializeComponent();
        }

        private void tblBugDataBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tblBugDataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bugDatabaseDataSet);

        }

        private void frmBugTracker_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bugDatabaseDataSet.tblBugData' table. You can move, or remove it, as needed.
            this.tblBugDataTableAdapter.Fill(this.bugDatabaseDataSet.tblBugData);
            cboBugSelection.Focus();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            // Close application
            Application.Exit();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            // get name
            int intID = int.Parse(bugIdTextBox.Text);
            // create instance of second form
            frmAdd_Edit AddForm = new frmAdd_Edit();
            // pass name  to second form
            AddForm.intID = intID;
            // display second form
            AddForm.ShowDialog();
            // refresh datagrid view to display updates
            this.tblBugDataTableAdapter.Fill(this.bugDatabaseDataSet.tblBugData);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // create instance of third form
            frmAdd AddForm = new frmAdd();
            // display second form
            AddForm.ShowDialog();
            // refresh datagrid view to display updates
            this.tblBugDataTableAdapter.Fill(this.bugDatabaseDataSet.tblBugData);
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            

        }

        private void cboBugSelection_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void bugIdTextBox_TextChanged(object sender, EventArgs e)
        {
            bugIdTextBox.Visible = false;
        }
    }
}
