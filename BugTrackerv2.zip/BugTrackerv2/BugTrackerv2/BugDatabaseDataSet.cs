﻿namespace BugTrackerv2
{


    partial class BugDatabaseDataSet
    {
        partial class tblBugDataDataTable
        {
        }
    }
}

namespace BugTrackerv2.BugDatabaseDataSetTableAdapters {
    
    
    public partial class tblBugDataTableAdapter {
    }
}
