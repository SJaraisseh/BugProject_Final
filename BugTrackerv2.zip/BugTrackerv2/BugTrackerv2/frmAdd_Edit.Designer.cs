﻿
namespace BugTrackerv2
{
    partial class frmAdd_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label bugNameLabel1;
            System.Windows.Forms.Label bugTypeLabel1;
            System.Windows.Forms.Label bugColorLabel1;
            System.Windows.Forms.Label bugLengthLabel1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdd_Edit));
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bugNameTextBox = new System.Windows.Forms.TextBox();
            this.tblBugDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bugDatabaseDataSet = new BugTrackerv2.BugDatabaseDataSet();
            this.bugTypeTextBox = new System.Windows.Forms.TextBox();
            this.bugColorTextBox = new System.Windows.Forms.TextBox();
            this.bugLengthTextBox = new System.Windows.Forms.TextBox();
            this.tblBugDataTableAdapter = new BugTrackerv2.BugDatabaseDataSetTableAdapters.tblBugDataTableAdapter();
            this.tableAdapterManager = new BugTrackerv2.BugDatabaseDataSetTableAdapters.TableAdapterManager();
            this.label3 = new System.Windows.Forms.Label();
            this.bugPicPictureBox = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnDelete = new System.Windows.Forms.Button();
            bugNameLabel1 = new System.Windows.Forms.Label();
            bugTypeLabel1 = new System.Windows.Forms.Label();
            bugColorLabel1 = new System.Windows.Forms.Label();
            bugLengthLabel1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblBugDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bugDatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bugPicPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // bugNameLabel1
            // 
            bugNameLabel1.AutoSize = true;
            bugNameLabel1.Font = new System.Drawing.Font("Pristina", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            bugNameLabel1.ForeColor = System.Drawing.Color.Teal;
            bugNameLabel1.Location = new System.Drawing.Point(18, 27);
            bugNameLabel1.Name = "bugNameLabel1";
            bugNameLabel1.Size = new System.Drawing.Size(117, 52);
            bugNameLabel1.TabIndex = 2;
            bugNameLabel1.Text = "Name:";
            // 
            // bugTypeLabel1
            // 
            bugTypeLabel1.AutoSize = true;
            bugTypeLabel1.Font = new System.Drawing.Font("Pristina", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            bugTypeLabel1.ForeColor = System.Drawing.Color.DodgerBlue;
            bugTypeLabel1.Location = new System.Drawing.Point(18, 78);
            bugTypeLabel1.Name = "bugTypeLabel1";
            bugTypeLabel1.Size = new System.Drawing.Size(104, 52);
            bugTypeLabel1.TabIndex = 4;
            bugTypeLabel1.Text = "Type:";
            // 
            // bugColorLabel1
            // 
            bugColorLabel1.AutoSize = true;
            bugColorLabel1.Font = new System.Drawing.Font("Pristina", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            bugColorLabel1.ForeColor = System.Drawing.Color.Plum;
            bugColorLabel1.Location = new System.Drawing.Point(18, 130);
            bugColorLabel1.Name = "bugColorLabel1";
            bugColorLabel1.Size = new System.Drawing.Size(103, 52);
            bugColorLabel1.TabIndex = 6;
            bugColorLabel1.Text = "Color:";
            // 
            // bugLengthLabel1
            // 
            bugLengthLabel1.AutoSize = true;
            bugLengthLabel1.Font = new System.Drawing.Font("Pristina", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            bugLengthLabel1.ForeColor = System.Drawing.Color.MediumVioletRed;
            bugLengthLabel1.Location = new System.Drawing.Point(18, 182);
            bugLengthLabel1.Name = "bugLengthLabel1";
            bugLengthLabel1.Size = new System.Drawing.Size(126, 52);
            bugLengthLabel1.TabIndex = 8;
            bugLengthLabel1.Text = "Length:";
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("OCR A Extended", 15F);
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.Location = new System.Drawing.Point(486, 451);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(194, 36);
            this.btnCancel.TabIndex = 12;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(486, 367);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(194, 36);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Font = new System.Drawing.Font("OCR A Extended", 15F);
            this.btnBrowse.Image = ((System.Drawing.Image)(resources.GetObject("btnBrowse.Image")));
            this.btnBrowse.Location = new System.Drawing.Point(12, 367);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(183, 36);
            this.btnBrowse.TabIndex = 14;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Turquoise;
            this.groupBox1.Controls.Add(bugNameLabel1);
            this.groupBox1.Controls.Add(this.bugNameTextBox);
            this.groupBox1.Controls.Add(bugTypeLabel1);
            this.groupBox1.Controls.Add(this.bugTypeTextBox);
            this.groupBox1.Controls.Add(bugColorLabel1);
            this.groupBox1.Controls.Add(this.bugColorTextBox);
            this.groupBox1.Controls.Add(bugLengthLabel1);
            this.groupBox1.Controls.Add(this.bugLengthTextBox);
            this.groupBox1.Location = new System.Drawing.Point(201, 116);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(479, 245);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // bugNameTextBox
            // 
            this.bugNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblBugDataBindingSource, "bugName", true));
            this.bugNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.25F);
            this.bugNameTextBox.Location = new System.Drawing.Point(167, 27);
            this.bugNameTextBox.MaxLength = 50;
            this.bugNameTextBox.Name = "bugNameTextBox";
            this.bugNameTextBox.Size = new System.Drawing.Size(295, 44);
            this.bugNameTextBox.TabIndex = 3;
            // 
            // tblBugDataBindingSource
            // 
            this.tblBugDataBindingSource.DataMember = "tblBugData";
            this.tblBugDataBindingSource.DataSource = this.bugDatabaseDataSet;
            // 
            // bugDatabaseDataSet
            // 
            this.bugDatabaseDataSet.DataSetName = "BugDatabaseDataSet";
            this.bugDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bugTypeTextBox
            // 
            this.bugTypeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblBugDataBindingSource, "bugType", true));
            this.bugTypeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.25F);
            this.bugTypeTextBox.Location = new System.Drawing.Point(167, 79);
            this.bugTypeTextBox.MaxLength = 50;
            this.bugTypeTextBox.Name = "bugTypeTextBox";
            this.bugTypeTextBox.Size = new System.Drawing.Size(295, 44);
            this.bugTypeTextBox.TabIndex = 5;
            // 
            // bugColorTextBox
            // 
            this.bugColorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblBugDataBindingSource, "bugColor", true));
            this.bugColorTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.25F);
            this.bugColorTextBox.Location = new System.Drawing.Point(167, 131);
            this.bugColorTextBox.MaxLength = 50;
            this.bugColorTextBox.Name = "bugColorTextBox";
            this.bugColorTextBox.Size = new System.Drawing.Size(295, 44);
            this.bugColorTextBox.TabIndex = 7;
            // 
            // bugLengthTextBox
            // 
            this.bugLengthTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblBugDataBindingSource, "bugLength", true));
            this.bugLengthTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.25F);
            this.bugLengthTextBox.Location = new System.Drawing.Point(167, 183);
            this.bugLengthTextBox.MaxLength = 50;
            this.bugLengthTextBox.Name = "bugLengthTextBox";
            this.bugLengthTextBox.Size = new System.Drawing.Size(295, 44);
            this.bugLengthTextBox.TabIndex = 9;
            // 
            // tblBugDataTableAdapter
            // 
            this.tblBugDataTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tblBugDataTableAdapter = this.tblBugDataTableAdapter;
            this.tableAdapterManager.UpdateOrder = BugTrackerv2.BugDatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Pristina", 50.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.SystemColors.Menu;
            this.label3.Location = new System.Drawing.Point(210, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(289, 90);
            this.label3.TabIndex = 16;
            this.label3.Text = "Edit Entry";
            // 
            // bugPicPictureBox
            // 
            this.bugPicPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.bugPicPictureBox.DataBindings.Add(new System.Windows.Forms.Binding("Image", this.tblBugDataBindingSource, "bugPic", true));
            this.bugPicPictureBox.Location = new System.Drawing.Point(10, 116);
            this.bugPicPictureBox.Name = "bugPicPictureBox";
            this.bugPicPictureBox.Size = new System.Drawing.Size(185, 245);
            this.bugPicPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bugPicPictureBox.TabIndex = 17;
            this.bugPicPictureBox.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(543, 34);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(74, 65);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 31;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(251, 419);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(87, 62);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 32;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(113, 27);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(91, 83);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 34;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(91, 419);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(87, 62);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 33;
            this.pictureBox3.TabStop = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.LightPink;
            this.btnDelete.Font = new System.Drawing.Font("OCR A Extended", 15F);
            this.btnDelete.Location = new System.Drawing.Point(486, 409);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(194, 36);
            this.btnDelete.TabIndex = 35;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // frmAdd_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(691, 493);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.bugPicPictureBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Name = "frmAdd_Edit";
            this.Text = "Edit";
            this.Load += new System.EventHandler(this.frmAdd_Edit_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblBugDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bugDatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bugPicPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BugDatabaseDataSet bugDatabaseDataSet;
        private System.Windows.Forms.BindingSource tblBugDataBindingSource;
        private BugDatabaseDataSetTableAdapters.tblBugDataTableAdapter tblBugDataTableAdapter;
        private BugDatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox bugNameTextBox;
        private System.Windows.Forms.TextBox bugTypeTextBox;
        private System.Windows.Forms.TextBox bugColorTextBox;
        private System.Windows.Forms.TextBox bugLengthTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox bugPicPictureBox;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnDelete;
    }
}